sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("dealertemplate.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);